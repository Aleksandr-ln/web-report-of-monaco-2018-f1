import argparse
import os

from .report import (
    build_report, format_timedelta, parse_abbreviations,
    sort_race_results, print_report
)


def main():
    parser = argparse.ArgumentParser(
        description="Generate a report for the Monaco 2018 Formula 1 Q1 stage."
    )
    parser.add_argument(
        "--files",
        required=True,
        help="Path to the folder containing the log files "
             "(start.log, end.log, abbreviations.txt).",
    )
    parser.add_argument(
        "--asc",
        action="store_true",
        help="Sort results in ascending order (default).",
    )
    parser.add_argument(
        "--desc",
        action="store_true",
        help="Sort results in descending order.",
    )
    parser.add_argument(
        "--driver",
        type=str,
        help="Show statistics for a specific driver.",
    )

    args = parser.parse_args()

    folder_path = os.path.abspath(args.files)
    start_file = os.path.join(folder_path, "start.log")
    end_file = os.path.join(folder_path, "end.log")
    abbreviations_file = os.path.join(folder_path, "abbreviations.txt")

    for file in [start_file, end_file, abbreviations_file]:
        if not os.path.exists(file):
            print(f"Error: File not found: {file}")
            return

    abbreviations = parse_abbreviations(str(abbreviations_file))
    race_results = build_report(str(start_file), str(
        end_file), str(abbreviations_file))

    if args.driver:
        driver = next(
            (abbr for abbr, racer in abbreviations.items()
             if racer.name == args.driver),
            None,
        )
        if driver:
            racer = abbreviations[driver]
            lap_time = (
                race_results[driver].lap_time
                if driver in race_results
                else None
            )
            if lap_time:
                print(
                    f"{racer.name:<20} | "
                    f"{racer.team:<30} | "
                    f"{format_timedelta(lap_time)}"
                )
            else:
                print(f"No lap time recorded for {args.driver}.")
        else:
            print(f"Driver '{args.driver}' not found.")
        return

    order = "desc" if args.desc else "asc"
    sorted_results = sort_race_results(race_results, order)
    print(print_report(sorted_results))


if __name__ == "__main__":
    main()
